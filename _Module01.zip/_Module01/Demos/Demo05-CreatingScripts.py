# This is the script's header
# ------------------------------------------------------------------------------------------ #
# Title: <Simple title for script>
# Desc: <Simple description of what the script does>
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   <Your Name Here>,<Date>, <Activity>
# ------------------------------------------------------------------------------------------ #

# Optional setup code (more on this later)

# This is the script's body
print("This is a test")